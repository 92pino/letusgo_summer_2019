//
//  PhotoResponse.swift
//  PhotoList
//
//  Created by Kawoou on 30/07/2019.
//  Copyright © 2019 kawoou. All rights reserved.
//

import Foundation

struct PhotoResponse: Codable {
    let list: [Photo]
}
